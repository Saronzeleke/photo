/your-project-folder
    - index.html
    - style.css
    - game.js
    - update_game.php
To run the game, ensure you have a local server running XAMP. For example:

In XAMPP, place the project folder in the htdocs directory.
Start Apache.
Access your game by going to http://localhost/your-project-folder/.