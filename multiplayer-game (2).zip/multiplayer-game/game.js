// Player health initialization (default for UI)
let player1Health = 100;
let player2Health = 100;

// Function to attack and communicate with PHP backend
function attack(player) {
    // Prepare form data to send the attacker info (player1 or player2)
    const formData = new FormData();
    formData.append('attacker', player);

    // Send a POST request to the PHP file
    fetch('update_game.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())  // Parse the JSON response
    .then(data => {
        // Update the health values in the UI
        document.getElementById('player1-health').innerText = data.player1Health;
        document.getElementById('player2-health').innerText = data.player2Health;

        // Display which player attacked and the damage dealt
        const opponent = (player === 'player1') ? 'Player 2' : 'Player 1';
        document.getElementById('game-status').innerText = `${opponent} takes ${data.damage} damage!`;

        // Check if there's a winner after the attack
        checkWinner(data.player1Health, data.player2Health);
    })
    .catch(error => console.error('Error:', error)); // Handle any errors
}

// Function to check if there's a winner
function checkWinner(player1Health, player2Health) {
    if (player1Health <= 0) {
        document.getElementById('game-status').innerText = 'Player 2 wins!';
        disableButtons();
    } else if (player2Health <= 0) {
        document.getElementById('game-status').innerText = 'Player 1 wins!';
        disableButtons();
    }
}

// Disable attack buttons once the game ends
function disableButtons() {
    document.querySelectorAll('button').forEach(button => {
        button.disabled = true;
    });
}
