<?php
session_start();

// Initialize health values if not set
if (!isset($_SESSION['player1Health'])) {
    $_SESSION['player1Health'] = 100;
}
if (!isset($_SESSION['player2Health'])) {
    $_SESSION['player2Health'] = 100;
}

// Get which player attacked
$attacker = $_POST['attacker'];
$damage = rand(1, 10); // Random damage between 1-10

// Update the opponent's health based on who attacked
if ($attacker == 'player1') {
    $_SESSION['player2Health'] -= $damage;
} else {
    $_SESSION['player1Health'] -= $damage;
}

// Return the updated health values as JSON
$response = array(
    'player1Health' => $_SESSION['player1Health'],
    'player2Health' => $_SESSION['player2Health'],
    'damage' => $damage,
);

header('Content-Type: application/json');
echo json_encode($response);
?>
